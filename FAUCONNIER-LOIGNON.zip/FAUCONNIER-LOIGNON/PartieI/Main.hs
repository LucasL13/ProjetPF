import EnvInteractif

-- Lance la boucle principale avec un store vide pour commencer
main = mainLoop []
